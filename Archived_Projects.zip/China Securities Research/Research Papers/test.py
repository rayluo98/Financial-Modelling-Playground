# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 09:07:28 2019

@author: raymo
"""

for i in range(1, 9):
  print(i)